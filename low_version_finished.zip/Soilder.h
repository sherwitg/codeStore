﻿#pragma once
#include<iostream>
using namespace std;
class Soilder
{
protected:

	int fixedHP = 100, fixedWealth = 0;	//用户自定义游戏参数
	int hitPoints;						//当前角色生命值
	int wealthValue;					//当前角色财富值
	int count = 0;						//记录走过的城堡次序(path数组下标)
	int* path;							//记录前进的路径
	bool* vis;							//指向访问标志数组的指针
	int myLuckCount = 0;				//幸运使用次数计数
public:					
	Soilder(){}
	Soilder(Soilder& s)
	{
		this->fixedHP = s.hitPoints;
		this->fixedWealth = s.wealthValue;
	}
	Soilder(int hp, int wv)//初始化
	{
		this->fixedHP = this->hitPoints = hp;
		this->fixedWealth = this->wealthValue = wv;
		path = new int[100];//每个城堡可以前往不止一次，定义一个尽量大的路径数组
		vis = new bool[100] {0};
		path[0] = 0;
	}
	int GetPath(int i) { return path[i]; }			//获取战士走过的城堡序号
	int GetCount() const{ return count; }			//获取战士走过的城堡次序(path数组下标)
	int GetCurPos() { return GetPath(count); }	//获取当前位置
	int GetHP() const { return this->hitPoints; }	//获取当前生命值
	int GetWV() const { return this->wealthValue; }	//获取当前财富值
	void UpdateGame()
	{
		this->hitPoints = this->fixedHP;
		this->wealthValue = this->fixedWealth;
		path = new int[100];//每个城堡可以前往不止一次，定义一个尽量大的路径数组
		vis = new bool[100] {0};
		path[0] = 0;
		count = 0;
	}
	bool goNext(int luck, int harm, int wealth, int v)		//去往下一个城堡
	{
		if (myLuckCount != luck && this->hitPoints - harm <= 0)
		{
			cout << "消耗一次替身机会，去往该城堡不是明智的选择" << endl;
			myLuckCount++;
			return 0;
		}
		else
		{
			if (!vis[v])
			{
				path[++count] = v;
				this->hitPoints -= harm;				//去往下一个城堡v时减少生命值
				this->wealthValue += wealth;			//若该城堡未被探索过，获取财富值
				vis[v] = 1;
			}
			else
			{
				path[++count] = v;
				this->hitPoints -= harm;
			}
		}
		return 1;
	}
	bool Display(const char& e)const						//展示勇士当前位置，生命值，财富值
	{
		if (this->hitPoints <= 0)
		{
			cout << "勇士已死亡" << endl;
			return 0;
		}
		else
		{
			cout << "勇士当前在" << e <<"城堡"<< endl;

			cout << "当前生命值:" << hitPoints << endl;
			cout << "当前财富值:" << wealthValue << endl;
			return 1;
		}
	}
};

