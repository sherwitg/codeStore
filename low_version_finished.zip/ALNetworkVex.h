﻿#pragma once
#include"ALNetworkArc.h"
class ALNetworkVex {
public:
	char data;											//城堡名称
	int vexWeight;										//城堡财富值
	ALNetworkArc *firstarc;								//指向弧链表的头指针
	int x, y;											//确定城堡在地图上的坐标
	ALNetworkVex()	     		       					//无参构造函数，创建一个空的顶点节点
	{
		firstarc = NULL;
	}
	ALNetworkVex(char& e, int vWeight, ALNetworkArc *arc = NULL) //有参构造函数
	{
		data = e; vexWeight = vWeight; firstarc = arc;
	}
};
