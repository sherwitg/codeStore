﻿#include"Map.h"


int main()
{
	//开始界面
	int i = 0;
	while (i != 3)
	{
		Map m1;
		Soilder s1(100, 0);
		m1.CreateMap();
		m1.UpdateGame();
		cout << "|  主菜单  |" << endl;
		cout << "|1.开始游戏|" << endl;
		cout << "|2.最优路线|" << endl;
		cout << "|3.结束游戏|" << endl;
		cin >> i;
		if (i == 1)
		{
			char nextpos, propos = 'A';
			while(s1.GetHP() > 0 && s1.GetCurPos() < m1.GetVexMaxSize() - 1)
			{
				m1.nextInf(s1);
				cin >> nextpos;
				int v1, v2;
				v2 = m1.GetOrder(nextpos);
				v1 = m1.GetOrder(propos);
				if(m1.check(v1, v2))
				{
					bool ans = s1.goNext(0, m1.GetWeight(v1, v2), m1.GetWeight(v2), v2);
					if (ans)propos = nextpos;
				}
			}
			if (s1.GetHP() <= 0)cout << "勇士已死亡" << endl;
			else cout << "游戏胜利！" << endl;
		}
		else if (i == 2)
		{
			int j = 0;
			while(j != 3)
			{
				cout << "|1.小心为上  |" << endl;
				cout << "|2.富贵险中求|" << endl;
				cout << "|3.返回主菜单|" << endl;
				cout << "|4.结束游戏  |" << endl;
				cin >> j;
				if (j == 1)
					m1.FindSafestLoad(s1, 0);
				else if (j == 2)
					m1.FindRichestLoad(s1, 0);
				else if (j == 3)
					continue;
				else if (j == 4)
				{
					cout << "游戏已结束" << endl;
					return 0;
				}
				else
					cout << "输入有误，请重新输入" << endl;
			}
		}
		else if (i == 3)
		{
			cout << "游戏已结束" << endl;
			return 0;
		}
		else
			cout << "输入有误，请重新输入" << endl;
		cout << endl;
	}

}