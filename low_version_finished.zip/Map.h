﻿#include<fstream>
#include "Status.h"
#include "ALNetworkVex.h"
#include"Soilder.h"
const int DEFAULT_SIZE = 100;
const int DEFAULT_INFINITY = 0x3f3f3f3f;

class Map
{
protected:
	int vexNum=0, vexMaxSize, arcNum=0;			//实际顶点数目，顶点数组容量和实际弧数
	ALNetworkVex* vexs;							//指向顶点数组的指针
	ALNetworkArc* arcs;							//指向弧数组的指针
	int infinity;								//存储表示无穷大的值
	Status* visited;							//指向访问标志数组的指针
	int* safestDist;							//记录边权(生命值)
	int* safestPath;							//记录生命值最高路径
	int* richestDist;							//记录点权(财富值)
	int* richestPath;							//记录财富值最高路径
	int resWealth;								//最高财富值
	Soilder s;
public:
	//构造函数，创建顶点数组容量为vexsize的空有向网
	Map(int vexsize = DEFAULT_SIZE, int infinit = DEFAULT_INFINITY);
	//构造函数，创建包含vertexnum个顶点，没有弧的有向网
	Map(char data[], int vertexnum, int vexsize = DEFAULT_SIZE, int infinit = DEFAULT_INFINITY);
	virtual ~Map();					 				//析构函数
	void Clear();									//清空地图
	bool IsEmpty()const;							//判断地图是否为空
	int GetOrder(const char& e) const;				//获取城堡名称为e的顶点序号
	Status GetElem(int v, char& e) const;			//获取顶点v的城堡名称
	int GetInfinity() const;						//获取表示无穷大的值
	int GetVexNum() const;							//获取当前顶点数目
	int GetVexMaxSize() const;						//获取最大顶点数目
	int GetArcNum() const;							//获取当前弧的数目
	int GetFirstAdjvex(int v) const;				//获取顶点v的第一个邻接点
	int GetNextAdjvex(int v1, int v2)const;			//获取顶点v1相对于v2的后继邻接点
	Status InsertVex(const char& e, int VexWeight);	//插入数据元素值为e,权值为VexWeight的顶点
	Status InsertArc(int v1, int v2, int w);		//插入顶点v1<->v2，权为w的弧
	int GetWeight(int v1, int v2) const; 			//获取从顶点v1到v2的弧的权值
	int GetWeight(int v) const; 					//获取从顶点v的权值
	Status SetWeight(int v1, int v2, int w);		//设置从顶点v1到v2的弧的权值为w
	Status GetVisitedTag(int v) const;				//获取顶点v的访问标志
	Status SetVisitedTag(int v, Status tag) const;	//修改顶点v的访问标志为tag
	void Display();									//显示有向网邻接表 

	bool CreateMap();									//根据文件创建地图
	void FindSafestLoad(Soilder& s, int v0);			//小心为上
	void OutputSafestLoad(int start);					//输出生命值最高的路线
	void FindRichestLoad(Soilder& s, int v0);			//富贵险中求
	void OutputRichestLoad(int curHP, int start)const;	//输出财富值最高的路线
	void DFS(Soilder& s, int in, int v, int& hp, int& maxWealth, int* tmpPath); //DFS+剪枝求财富值最高的路线
	void nextInf(Soilder& s)const;
	bool check(int v1, int v2);
	//提示下座城堡的信息
	void UpdateGame()const;								//刷新地图
};

//构造函数，创建顶点数组容量为vexsize的空有向网
Map::Map(int vexsize, int infinit)
{
	vexNum = 0;  vexMaxSize = vexsize;  arcNum = 0;  infinity = infinit;
	vexs = new ALNetworkVex[vexMaxSize]; 		//分配顶点数组
	arcs = new ALNetworkArc[arcNum];
	visited = new Status[vexMaxSize]; 								//分配访问标志数组
	for (int v = 0; v < vexNum; v++) {								//初始化顶点数组、访问标志数组
		vexs[v].firstarc = NULL;
		visited[v] = UNVISITED;
	}
}

//构造函数，创建包含vertexnum个顶点，没有弧的有向网
Map::Map(char data[], int vertexnum, int vexsize, int infinit) {
	if (vexsize < vertexnum)
	{
		cout << "顶点数目不能大于允许的顶点最大数目! ";
		return;
	}
	vexNum = vertexnum;  vexMaxSize = vexsize;  arcNum = 0;  infinity = infinit;
	vexs = new ALNetworkVex[vexMaxSize]; 		//分配顶点数组
	arcs = new ALNetworkArc[arcNum];
	visited = new Status[vexMaxSize]; 								//分配访问标志数组
	for (int v = 0; v < vexNum; v++) {								//初始化顶点数组、访问标志数组
		vexs[v].data = data[v];  vexs[v].firstarc = NULL;
		visited[v] = UNVISITED;
	}
}

Map::~Map() {	//析构函数
	Clear();
	delete[]vexs;
	delete[]arcs;
	delete[]visited;
}

void Map::Clear() {		//清空有向网
	ALNetworkArc* p;
	for (int v = 0; v < vexNum; v++) {					//释放邻接点链表，重置访问标志数组
		p = vexs[v].firstarc;
		while (p) {
			vexs[v].firstarc = p->nextarc;
			delete p;
			p = vexs[v].firstarc;
		}
		visited[v] = UNVISITED;
	}
	vexNum = 0;  arcNum = 0;
}

bool Map::IsEmpty()const {	//判断有向网是否为空
	return vexNum ? false : true;
}

int Map::GetOrder(const char& e) const {	//获取数据元素等于e的顶点序号
	for (int v = 0; v < vexNum; v++)					//遍历顶点数组
		if (vexs[v].data == e)						//判断顶点的数据元素是否等于e
			return v;								//相等则返回顶点下标
	return -1;										//未找到，返回-1
}

Status Map::GetElem(int v, char& e) const {	//获取顶点v的数据元素值
	if (v < 0 || v >= vexNum)						//判断v是否越界
	{
		cout << "v取值不合法!" << endl;  return FAILED;
	}
	e = vexs[v].data;
	return SUCCESS;
}

int Map::GetInfinity() const {	//获取表示无穷大的值
	return infinity;
}

int Map::GetVexNum() const {	//获取当前顶点数目
	return vexNum;
}

int Map::GetVexMaxSize() const {	//获取最大顶点数目
	return vexMaxSize;
}

int Map::GetArcNum() const {	//获取当前弧的数目
	return arcNum;
}

int Map::GetFirstAdjvex(int v) const {	//获取顶点v的第一个邻接点
	if (v < 0 || v >= vexNum)						//判断v是否越界
	{
		cout << "v取值不合法!" << endl;  return -1;
	}
	if (vexs[v].firstarc == NULL)  return -1;		//不存在邻接点
	else  return vexs[v].firstarc->v1;			//返回第一个弧节点记录的弧头顶点序号
}

int Map::GetNextAdjvex(int v1, int v2) const {	//获取顶点v1相对于v2的后继邻接点
	ALNetworkArc* p;
	if (v1 < 0 || v1 >= vexNum) 						//判断v1是否越界
	{
		cout << "v1取值不合法!" << endl;  return -1;
	}
	if (v2 < 0 || v2 >= vexNum)						//判断v2是否越界
	{
		cout << "v2取值不合法!" << endl;  return -1;
	}
	if (v1 == v2) 									//判断v1和v2是否相等
	{
		cout << "v1与v2不能相等!" << endl;  return -1;
	}
	p = vexs[v1].firstarc;							//p指向弧链表的第一个弧节点
	while (p != NULL && p->v1 != v2)				//寻找v2所在的弧节点
		p = p->nextarc;
	if (p == NULL || p->nextarc == NULL)  return -1;	//不存在后继邻接点
	else  return p->nextarc->v1;				//返回后继弧节点记录的弧头顶点序号
}


Status Map::InsertVex(const char& e, int VexWeight) {	//插入数据元素值为e的顶点
	if (vexNum == vexMaxSize)  return OVER_FLOW;		//顶点数组已满
	vexs[vexNum].data = e;								//将顶点数据存储到顶点数组尾部
	vexs[vexNum].vexWeight = VexWeight;					//城堡财富值
	vexs[vexNum].firstarc = NULL;
	visited[vexNum] = UNVISITED;
	vexNum++;
	return SUCCESS;
}

Status Map::InsertArc(int v1, int v2, int w) {	//插入顶点v1<->v2权为w的弧
	if (v1 < 0 || v1 >= vexNum) 						//判断v1是否越界
	{
		cout << "v1取值不合法!" << endl;  return FAILED;
	}
	if (v2 < 0 || v2 >= vexNum)						//判断v2是否越界
	{
		cout << "v2取值不合法!" << endl;  return FAILED;
	}
	if (v1 == v2) 									//判断v1和v2是否相等
	{
		cout << "v1与v2不能相等!" << endl;  return FAILED;
	}
	if (w == infinity)								//判断w取值是否为无穷
	{
		cout << "权值w不能为无穷大!" << endl;  return FAILED;
	}
	vexs[v1].firstarc = new ALNetworkArc(v2, w, vexs[v1].firstarc);
	arcNum++;
	return SUCCESS;
}

int Map::GetWeight(int v1, int v2) const {	//获取从顶点v1到v2的弧的权值
	if (v1 < 0 || v1 >= vexNum) 						//判断v1是否越界
	{
		cout << "v1取值不合法!" << endl;  return infinity;
	}
	if (v2 < 0 || v2 >= vexNum)						//判断v2是否越界
	{
		cout << "v2取值不合法!" << endl;  return infinity;
	}
	if (v1 == v2) 									//判断v1和v2是否相等
		return 0;
	ALNetworkArc* p;
	p = vexs[v1].firstarc;							//p指向第一个弧节点
	while (p && p->v1 != v2)						//寻找邻接点v2
		p = p->nextarc;
	if (!p)  return infinity;						//v2不是v1的邻接点，返回无穷
	return p->weight;								//返回从顶点v1到v2的弧的权值
}

int Map::GetWeight(int v) const {	//获取顶点v的权值
	if (v < 0 || v >= vexNum) 						//判断v是否越界
	{
		cout << "v取值不合法!" << endl;  return infinity;
	}
	return vexs[v].vexWeight;								//返回顶点v的权值
}

Status Map::SetWeight(int v1, int v2, int w) {	//设置从顶点v1到v2的弧的权值为w
	if (v1 < 0 || v1 >= vexNum) 						//判断v1是否越界
	{
		cout << "v1取值不合法!" << endl;  return FAILED;
	}
	if (v2 < 0 || v2 >= vexNum)						//判断v2是否越界
	{
		cout << "v2取值不合法!" << endl;  return FAILED;
	}
	if (v1 == v2) 									//判断v1和v2是否相等
	{
		cout << "v1与v2不能相等!" << endl;  return FAILED;
	}
	ALNetworkArc* p;
	p = vexs[v1].firstarc;							//p指向第一个弧节点
	while (p && p->v1 != v2)						//寻找邻接点v2
		p = p->nextarc;
	if (!p)  return FAILED;							//v2不是v1的邻接点，返回失败信息
	p->weight = w;									//修改从顶点v1到v2的弧的权值
	return SUCCESS;
}

Status Map::GetVisitedTag(int v) const {	//获取顶点v的访问标志
	if (v < 0 || v >= vexNum)						//判断v是否越界
	{
		cout << "v取值不合法!" << endl;  return FAILED;
	}
	return visited[v];
}

Status Map::SetVisitedTag(int v, Status tag) const {	//修改顶点v的访问标志为tag
	if (v < 0 || v >= vexNum)							//判断v是否越界
	{
		cout << "v取值不合法!" << endl;  return FAILED;
	}
	visited[v] = tag;
	return SUCCESS;
}

void Map::Display()	//显示有向网邻接表
{
	ALNetworkArc* p;
	cout << "有向网共有" << vexNum << "个顶点，" << arcNum << "条边。" << endl;
	for (int v = 0; v < vexNum; v++) {					//显示第v个邻接链表
		//cout << v << ":\t" << vexs[v].data;				// 显示顶点号
		p = vexs[v].firstarc;
		while (p != NULL) {
			//cout << "-->(" << p->v1 << "," << p->weight << ")";
			p = p->nextarc;
		}
		cout << endl;
	}
}

bool Map::CreateMap()
{
	ifstream infile;									//定义文件流对象(只读)
	infile.open("map.txt", ios::in);					//打开文件
	if (!infile.is_open())return 0;						//文件打开失败
	int vexNum,arcNum;
	infile >> vexNum >> arcNum;							//读入第一行，获取顶点数目和弧数目
	this->vexMaxSize = vexNum;
	for (int i = 1; i <= vexNum; i++)					//获取顶点名称信息
	{
		char ch;										//城堡名称
		int weight;										//城堡财富值
		infile >> ch >> weight;							//获取数据
		this->InsertVex(ch, weight);					//插入顶点
	}
	for (int i = 1; i <= arcNum; i++)					//创建无向弧
	{
		int v1, v2, w;
		infile >> v1 >> v2 >> w;						//依次输入弧尾节点，弧头节点，边权
		this->InsertArc(v1, v2, w);						//插入v1<->v2权值为w的边
	}
	infile.close();
	return 1;
}



//找到生命值最高的路径
void Map::FindSafestLoad(Soilder& s, int v0)
{
	safestPath = new int[vexMaxSize];
	safestDist = new int[vexMaxSize];
	int minharm, infinity = GetInfinity();
	int v, i, u;
	safestPath[0] = -1;										//起点没有前驱
	safestDist[0] = 0;										//初始状态伤害值为0
	for (v = v0 + 1; v < GetVexNum(); v++) {				//初始化数组dist、path及顶点标志
		safestDist[v] = GetWeight(v0, v);					//获取v0->v的权值
		if (safestDist[v] >= 100)  safestPath[v] = -1;		//勇士走上死路，表明不存在可行的v0->v路线
		else  safestPath[v] = v0;							//存在弧<v0，v>
		SetVisitedTag(v, UNVISITED);        				//置顶点访问标志为未访问，表示未确定最短路径
	}
	SetVisitedTag(v0, VISITED);								//无需寻找源点v0的最短路径
	for (int i = v0 + 1; i < GetVexNum(); i++) {			//寻找从源点v0到其他顶点的最短路径
		u = v0;  			  								//u记录当前距离值最小的顶点，初始化为源点
		minharm = infinity;									//minharm记录距离值的最小值，初始化为无穷
		//在尚未确定最短路径的顶点中寻找距离值最小的顶点
		for (v = 0; v < GetVexNum(); v++)
			if (GetVisitedTag(v) == UNVISITED && safestDist[v] < minharm)
			{
				u = v;	    minharm = safestDist[v];
			}
		SetVisitedTag(u, VISITED);							//确定了顶点u的最短路径
		//检查u的尚未确定最短路径的邻接点
		for (v = GetFirstAdjvex(u); v != -1; v = GetNextAdjvex(u, v))
			if (GetVisitedTag(v) == UNVISITED && minharm + GetWeight(u, v) < safestDist[v]) {
				//尚未确定v的最短路径并且从v0沿着u的最短路径到达u再经由<u, v>到达v更短
				safestDist[v] = minharm + GetWeight(u, v);	//修改顶点v的距离值
				safestPath[v] = u;							//修改顶点v的前驱
			}
	}
	OutputSafestLoad(v0);
}

void Map::OutputSafestLoad(int start)//输出生命值最高的路径
{
	if (safestDist[this->vexMaxSize - 1] >= 100)
	{
		cout << "不存在安全抵达终点的道路" << endl;
		return;
	}
	char* route = new char[GetVexNum()];
	int len = 0;
	char sdata, edata, tdata;
	this->GetElem(start, sdata);
	this->GetElem(this->vexMaxSize - 1, edata);
	route[len++] = edata;
	for (int j = this->vexMaxSize - 1; safestPath[j] != -1; j = safestPath[j])
	{
		this->GetElem(safestPath[j], tdata);
		route[len++] = tdata;
	}
	cout << "当前位置开始的生命值最高的路径是：";
	for (int i = len - 1; i >= 0; i--)
		cout << route[i] << " ";
	cout << "，最高生命值是" << 100 - safestDist[this->vexMaxSize - 1] << endl;
	delete[]route;
}

//从源点v0开始找到财富最大且生命值不为零的路线
void Map::FindRichestLoad(Soilder& s, int v0)
{
	richestPath = new int[vexMaxSize];
	richestDist = new int[vexMaxSize];
	int v, limit = 100;
	for (v = 0; v <= s.GetCount(); v++)
		richestPath[v] = s.GetPath(v);//记录勇士第v次前进所在城堡位置
	int curHP = 100;
	int maxWealth = 0;
	int* tmpPath = new int[vexMaxSize];
	tmpPath[0] = 0;
	DFS(s, 1, v0, curHP, maxWealth, tmpPath);
	resWealth += s.GetWV();
	OutputRichestLoad(curHP, v0);
}

void Map::DFS(Soilder& s, int in, int v, int& hp, int& maxWealth, int* tmpPath)
{
	//DFS+剪枝(回溯法)
	if (v == this->GetVexNum() - 1)//到达终点，找到一个可行解
	{
		maxWealth += GetWeight(v);
		tmpPath[in] = v;
		if (maxWealth > resWealth)//判断是否为更优解
		{
			resWealth = maxWealth;
			for (int i = 0; i <= this->GetVexMaxSize() - 1; i++)
			{
				richestPath[i + s.GetCount()] = tmpPath[i];
			}
		}
		maxWealth -= GetWeight(v);
		return;
	}
	if (hp - GetWeight(tmpPath[in - 1], v) > 0)//确保前往下一座城堡时角色未死亡
	{
		SetVisitedTag(v, VISITED);
		maxWealth += GetWeight(v);
		tmpPath[in] = v;
		hp -= GetWeight(tmpPath[in - 1], v);
		for (int w = GetFirstAdjvex(v); w != -1; w = GetNextAdjvex(v, w))
			if (GetVisitedTag(w) == UNVISITED)
			{
				DFS(s, in + 1, w, hp, maxWealth, tmpPath);
				SetVisitedTag(w, UNVISITED);
			}
	}
	else
		return;
}

void Map::OutputRichestLoad(int curHP, int start)const
{
	if (curHP <= 0)
	{
		cout << "不存在安全抵达终点的道路" << endl;
		return;
	}
	char* route = new char[GetVexNum()];
	int len = 0;
	char sdata, tdata;
	this->GetElem(start, sdata);
	for (int j = 0; richestPath[j] >= 0 && richestPath[j] <= GetVexNum()-1; j++)
	{
		this->GetElem(richestPath[j], tdata);
		route[len++] = tdata;
	}
	cout << "当前位置开始的财富值最高的路径是：";
	for (int i = 1; i <= len-1; i++)
		cout << route[i] << " ";
	cout << "，最高财富值是" << resWealth;
	cout << "，当前生命值是" << curHP << endl;
	delete[]route;
}

void Map::nextInf(Soilder& s)const
{
	int v;
	int vnext;
	v = s.GetPath(s.GetCount());
	vnext = this->GetFirstAdjvex(v); 
	cout << "- - - - - - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
	cout << "| 							|" << endl;
	cout<<"|		 选择前往的下一座城堡：";
	while (vnext >= 0 && vnext< this->GetVexMaxSize())//获取v的所有邻接点
	{
		char e;
		GetElem(vnext, e);
		cout << e << " ";
		vnext = GetNextAdjvex(v, vnext);
	}
	cout << "		| " << endl;
	cout << "| 							|" << endl;
	cout << "- - - - - - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
}

bool Map::check(int v1, int v2)
{
	if (v1 == v2)
	{
		cout << "你已经在该城堡，请重新输入" << endl;
		return 0;
	}
	int vnext;
	vnext = this->GetFirstAdjvex(v1);
	while (vnext >= 0 && vnext < this->GetVexMaxSize())//获取v的所有邻接点
	{
		if (vnext == v2)return 1;
		vnext = GetNextAdjvex(v1, vnext);
	}
	cout << "无法到达该城堡，请重新输入" << endl;
	return 0;
}
void Map::UpdateGame()const
{
	for (int i = 0; i <= vexMaxSize-1; i++)
		SetVisitedTag(i, UNVISITED);
}

